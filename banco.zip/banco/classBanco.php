<?php
class contaBanco{
    // Propriedades da classe
    public $numConta; // Número da conta
    protected $tipo; // Tipo da conta (CC para conta corrente, CP para conta poupança)
    private $dono; // Nome do titular da conta
    private $saldo = 0; // Saldo inicial da conta é zero
    private $status = false; // Status da conta (aberta ou fechada)

    //! Constructor
    // Método construtor da classe
    public function __construct($numConta, $tipo, $dono){
        $this->numConta = $numConta;
        $this->tipo = $tipo;
        $this->dono = $dono;
    }
    
    //* Métodos

    // Método para abrir uma conta
    public function abrirConta($dono){
        // Verifica o tipo de conta e define o saldo inicial correspondente
        if ($this->tipo == "CC") {
            $this->saldo = 50; // Saldo inicial de 50 para conta corrente
            echo "<p>A conta corrente vem com {$this->saldo} reais</p>";
        } else if ($this->tipo == "CP") {
            $this->saldo = 150; // Saldo inicial de 150 para conta poupança
            echo "<p>A conta poupança vem com {$this->saldo} reais!</p>";
        }

        // Verifica se a conta já está aberta
        if ($this->status == true) {
            echo "<p>Conta já aberta</p>"; // Mensagem de conta já aberta
        } else {
            $this->status = true; // Define o status da conta como aberta
            echo "<p>Conta aberta com sucesso</p>"; // Mensagem de conta aberta com sucesso
            $this->dono = $dono; // Define o nome do titular da conta
            echo "<p>Nome do titular: {$this->dono}</p>"; // Mensagem de nome do titular
        }
    }

    // Método para fechar uma conta
    public function fecharConta(){
        //!Verificar se a cont esta aberta

        if($this->status == true){
            //!Verificar se tem saldo
            if($this->saldo > 0){
                $this->status = false; // Define o status da conta como fechada
                echo "<p>Conta fechada com sucesso</p>"; // Mensagem de conta fechada com sucesso
            }else{
                echo "<p>Não há saldo para fechar a conta</p>"; // Mensagem de não há saldo para fechar a conta
            }
        }

        // Verifica se a conta já está fechada
        if ($this->status == false) {
            echo "Conta já fechada"; // Mensagem de conta já fechada
        } else {
            $this->status = false; // Define o status da conta como fechada
            echo "Conta fechada com sucesso"; // Mensagem de conta fechada com sucesso
        }
    }
    
    // Método para depositar um valor na conta
    public function depositar($valor){
        // Verifica se a conta está aberta
        if ($this->status == true) {
            $this->saldo += $valor; // Adiciona o valor ao saldo da conta
            echo "Depósito realizado com sucesso"; // Mensagem de depósito realizado com sucesso
        } else {
            echo "Conta não aberta"; // Mensagem de conta não aberta
        }
    }
    
    // Método para sacar um valor da conta
    public function sacar($valor){
        // Verifica se a conta está aberta
        if ($this->status == true) {
            // Verifica se o saldo é suficiente para o saque
            if ($valor <= $this->saldo) {
                
                $this->saldo -= $valor; // Subtrai o valor do saldo da conta
                echo "Saque realizado com sucesso"; // Mensagem de saque realizado com sucesso
            } else {
                echo "Saldo insuficiente"; // Mensagem de saldo insuficiente
            }
        } else {
            echo "Conta não aberta"; // Mensagem de conta não aberta
        }
    }
    
    // Métodos getters e setters para acesso às propriedades da classe

    // Método getter para obter o saldo da conta
    public function getSaldo(){
        return $this->saldo;
    }

    // Método getter para obter o dono da conta
    public function getDono(){
        return $this->dono;
    }

    // Método setter para definir o dono da conta
    public function setDono($dono){
        $this->dono = $dono;
    }

    // Método getter para obter o tipo da conta
    public function getTipo(){
        return $this->tipo;
    }

    // Método setter para definir o tipo da conta
    public function setTipo($tipo){
        $this->tipo = $tipo;
    }

    // Método getter para obter o status da conta
    public function getStatus(){
        return $this->status;
    }

    // Método setter para definir o saldo da conta
    public function setSaldo($saldo){
        $this->saldo = $saldo;
    }

    // Método para pagar a mensalidade da conta
    public function pagarMensal(){
        // Verifica se a conta está aberta
        if ($this->status == true) {
            // Verifica se o saldo é suficiente para pagar a mensalidade
            if ($this->saldo >= 12) {
                $this->saldo -= 12; // Subtrai o valor da mensalidade do saldo da conta
                echo "Mensalidade paga com sucesso"; // Mensagem de mensalidade paga com sucesso
            } else {
                echo "Saldo insuficiente"; // Mensagem de saldo insuficiente
            }
        } else {
            echo "Conta não aberta"; // Mensagem de conta não aberta
        }
    }
}
?>
